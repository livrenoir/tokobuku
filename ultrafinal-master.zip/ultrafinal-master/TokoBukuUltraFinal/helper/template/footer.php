<footer class="container-fluid text-center">
  <!-- <p><b>Copyright</b> &copy; -</p> -->
  <p><b>Copyright</b> &copy; TokoBuku.com</p>
</footer>