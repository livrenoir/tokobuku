<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="shortcut icon" href="public/image/asset/about.png" type="image/x-icon">
<link rel="stylesheet" href="public/bootstrap/css/bootstrap.css">
<link rel="stylesheet" href="public/css/style.css">
<link rel="stylesheet" href="public/awesome/css/font-awesome.css">
<script src="public/bootstrap/js/jquery.min.js"></script>
<script src="public/bootstrap/js/bootstrap.js"></script>

<style>
  @media (max-width: 600px) {
    .carousel-caption {
      display: none; 
    }
  }
 </style>